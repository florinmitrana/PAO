package Service;

import model.Broker;
import model.Transaction;

import java.util.List;
import java.util.Map;

public interface BrokerInt {
    public String getNume();

    public void setNume(String nume);

    public double getRataComision();

    public void setRataComision(double rataComision);

    public double calculeazaComision(Transaction tranzactie);
    public Map<Double, String> getBrokeriOrdonati(List<Broker> brokeri);
}
