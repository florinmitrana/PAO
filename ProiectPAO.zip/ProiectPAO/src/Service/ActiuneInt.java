package Service;

public interface ActiuneInt {
    public String getNume();

    public void setNume(String nume);

    public String getSimbol();

    public void setSimbol(String simbol);

    public double getPret();

    public void setPret(double pret);

    public long getMarketCap();

    public void setMarketCap(int marketCap);

}
