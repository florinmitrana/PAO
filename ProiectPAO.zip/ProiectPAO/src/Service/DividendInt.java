package Service;

import model.Actiune;

public interface DividendInt {
    public void dividendActiune(Actiune actiune, double valdiv);
}
