package Service;

import model.Actiune;
import model.Portofoliu;

public interface UtilizatorInt {
    public String getNume();

    public void setNume(String nume);

    public String getId();

    public void setId(String id);

    public String getAdresaEmail();

    public void setAdresaEmail(String adresaEmail);

    public Portofoliu getPortofoliu();

    public void setPortofoliu(Portofoliu portofoliu);

    public void adaugaActiuneInPortofoliu(Actiune actiune);

    public void afisareActiuni();

}

