package Service;
import model.Actiune;
import model.Portofoliu;
public interface ServTranzactionare {
    int numarActiuni(Portofoliu portofoliu, String numeActiune);

    double valoarePortofoliu(Portofoliu portofoliu);
}
