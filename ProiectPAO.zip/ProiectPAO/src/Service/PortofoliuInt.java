package Service;

import model.Actiune;

import java.util.List;

public interface PortofoliuInt {
    public void adaugaActiune(Actiune actiune);

    public void stergeActiune(Actiune actiune);

    public List<Actiune> getActiuni();

    public void CitireAfisareActiuniFisier();
}
