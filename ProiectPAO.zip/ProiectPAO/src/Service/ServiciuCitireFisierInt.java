package Service;

public interface ServiciuCitireFisierInt {
    public void CitireAfisareFisier(String NumeFisier);
}
