package Service;

import model.Actiune;
import model.Criptomoneda;
import model.Portofoliu;
import model.PortofoliuCrypto;

import java.util.Date;

public interface TransactionInt {
    public int getTransaction_id();

    public void setTransaction_id(int transaction_id);

    public Date getTransaction_time();

    public void setTransaction_time(Date transaction_time);

    public Portofoliu getPortofoliu();

    public Portofoliu getPortofoliuCrypto();

    public void setPortofoliuCrypto(PortofoliuCrypto portofoliuCrypto);

    public void setPortofoliu(Portofoliu portofoliu);

    public Actiune getActiune();

    public void setActiune(Actiune actiune);

    public int getTransaction_quantity();

    public void setTransaction_quantity(int transaction_quantity);

    public void cumparaActiuni();
    public void vindeActiuni();
    }

