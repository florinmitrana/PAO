import Implementation.*;
import model.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;


//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        String url = "jdbc:postgresql://localhost:5432/postgres";
        String user = "postgres";
        String password = "datadebaze";

        Actiune Apple = new Actiune("Apple Inc.", "AAPL", 150.0,200000);
        Actiune Google = new Actiune("Alphabe1t Inc.", "GOOGL",2000.0,500000);
        Criptomoneda Bitcoin = new Criptomoneda("Bitcoin","BTC",68.432,20000,6.25);
        Dividend d1 = new Dividend();

        List<Actiune> listaActiuni = new ArrayList<>();

        listaActiuni.add(Apple);
        listaActiuni.add(Google);
        listaActiuni.add(Bitcoin);

        Portofoliu portofoliuGiani = new Portofoliu();
        PortofoliuCrypto portofoliuGianiCrypto = new PortofoliuCrypto("HASH2b2344r3");

        Utilizator Giani = new Utilizator ("Giani", "gianistocks" ,"gianis@gmail.com", portofoliuGiani);
        Utilizator Florin = new Utilizator("Florin", "florinstocks","florin@gmail.com",portofoliuGiani);
        Calendar calendar = Calendar.getInstance();

        Transaction t1 = new Transaction(1, calendar.getTime(),portofoliuGiani,portofoliuGianiCrypto,Apple,5 );
        Transaction t2 = new Transaction(2, calendar.getTime(),portofoliuGiani,portofoliuGianiCrypto,Google,6);
        Transaction t3 = new Transaction(3, calendar.getTime(),portofoliuGiani,portofoliuGianiCrypto,Bitcoin,4);
        Transaction t4= new Transaction(4, calendar.getTime(), portofoliuGiani, portofoliuGianiCrypto , Apple, 5 );


        Broker b1 = new Broker("Broker 1", 9.42);
        Broker b2 = new Broker("Broker 2", 7.42);
        Broker b3 = new Broker("Broker 3 ",8.42);
        Broker b4 = new Broker("Broker 4 ", 1.23);

        try(Connection connection = DriverManager.getConnection(url,user,password)) {

            ActiuneService actiuneService = new ActiuneService(connection);
            TransactionService transactionService = new TransactionService(connection);
            UtilizatorService utilizatorService = new UtilizatorService(connection);
            BrokerService brokerService = new BrokerService(connection);

            //actiuni - baza de date
            actiuneService.insertActiuni(listaActiuni);
            actiuneService.selectActiune(Apple);
            actiuneService.selectActiune(Google);
            actiuneService.selectActiune(Bitcoin);
            actiuneService.updateActiune(Google,2,2050.0, 5000);
            actiuneService.selectActiune(Google);
            actiuneService.updateActiune(Apple,1,200.0,5000);
            actiuneService.selectActiune(Apple);
            actiuneService.deleteActiune(Apple);
            actiuneService.insertActiuni(listaActiuni);
            actiuneService.selectActiune(Apple);

            //tranzactii- baza de date

            transactionService.insertTranzactie(t1);
            transactionService.insertTranzactie(t2);
            transactionService.insertTranzactie(t3);
            transactionService.insertTranzactie(t4);

            transactionService.selectTranzactie(t2);

            transactionService.updateTranzactie(t2,7);

            transactionService.deleteTranzactie(t4);

            // utilizatori- baza de date

            utilizatorService.insertUtilizator(Giani);
            utilizatorService.insertUtilizator(Florin);

            utilizatorService.selectUtilizator(Giani);

            utilizatorService.updateUtilizator(Florin,"Dixanu", "Dixanu@gmail.com");

            utilizatorService.deleteUtilizator(Florin);

            // brokeri - baza de date

            brokerService.insertBroker(b1);
            brokerService.insertBroker(b2);
            brokerService.insertBroker(b3);
            brokerService.insertBroker(b4);

            brokerService.selectBroker(b2);

            brokerService.deleteBroker(b4);

            brokerService.updateBroker(b3, 5.2);

        } catch (SQLException e){
            System.out.println("Eroare la conectarea la baza de date: "+e.getMessage());

        }


        //ServiciuCitireFisier serviciuCitire = ServiciuCitireFisier.getInstance();
       // serviciuCitire.CitireAfisareFisier("src/Actiuni.csv");

        t1.cumparaActiuni();
        d1.dividendActiune(Apple,2.52);
        t2.cumparaActiuni();
        t3.cumparaActiuni();

        List<Broker> listaBrokeri = new ArrayList<>();

        listaBrokeri.add(b1);
        listaBrokeri.add(b2);
        listaBrokeri.add(b3);

        System.out.println("Comisionul brokerului "+b1.getNume()+ " pentru tranzactia "+t1.getTransaction_id()+" este de "+b1.calculeazaComision(t1)+"\n");
        System.out.println("Lista cu brokerii ordonati dupa rata de comision: "+ b1.getBrokeriOrdonati(listaBrokeri)+"\n");




        Giani.afisareActiuni();
        double valoare = Giani.valoarePortofoliu(portofoliuGiani);
        double valoareCrypto = Giani.valoarePortofoliu(portofoliuGianiCrypto);
        System.out.println("\nPortofoliul de actiuni al lui " + Giani.getNume() + " are valoarea totala de " + valoare);
        System.out.println("Portofoliul de criptomonede al lui " + Giani.getNume() + " are valoarea totala de " + valoareCrypto);
    }
}