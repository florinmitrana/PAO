package model;

public class PortofoliuCrypto extends Portofoliu {
    private String hash;

    public PortofoliuCrypto(String hash) {
        super();
        this.hash = hash;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }
}
