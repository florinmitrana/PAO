package model;
import model.Actiune;
public class Criptomoneda extends Actiune {
    private double BlockReward;
    public Criptomoneda(String nume, String simbol, double pret, int marketCap, double BlockReward) {
        super(nume, simbol, pret, marketCap);
        this.BlockReward = BlockReward;
    }

    public double getBlockReward() {
        return BlockReward;
    }

    public void setBlockReward(double blockReward) {
        BlockReward = blockReward;
    }

}


