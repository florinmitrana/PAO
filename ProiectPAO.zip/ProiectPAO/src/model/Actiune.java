package model;

import Service.ActiuneInt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Actiune implements ActiuneInt {
    private String nume;
    private String simbol;
    private double pret;
    private long MarketCap;


    public Actiune(String nume, String simbol, double pret, int marketCap) {
        this.nume = nume;
        this.simbol = simbol;
        this.pret = pret;
        MarketCap = marketCap;

    }
    @Override
    public String getNume() {
        return nume;
    }
    @Override
    public void setNume(String nume) {
        this.nume = nume;
    }
    @Override
    public String getSimbol() {
        return simbol;
    }
    @Override
    public void setSimbol(String simbol) {
        this.simbol = simbol;
    }
    @Override
    public double getPret() {
        return pret;
    }
    @Override
    public void setPret(double pret) {
        this.pret = pret;
    }
    @Override
    public long getMarketCap() {
        return MarketCap;
    }
    @Override
    public void setMarketCap(int marketCap) {
        MarketCap = marketCap;
    }

    @Override
    public String toString(){
        return nume;
    }

}
