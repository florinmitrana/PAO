package model;

import Service.PortofoliuInt;
import model.Actiune;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
public class Portofoliu implements PortofoliuInt {
    private List<Actiune> actiuni;

    public Portofoliu() {
        actiuni = new ArrayList<>();
    }

    @Override
    public void adaugaActiune(Actiune actiune) {
        actiuni.add(actiune);
    }

    @Override
    public void stergeActiune(Actiune actiune) {
        actiuni.remove(actiune);
    }

    @Override
    public List<Actiune> getActiuni() {
        return actiuni;
    }

    @Override
    public void CitireAfisareActiuniFisier() {
        String fisierActiuni = "src/Actiuni.csv";
        BufferedReader reader = null;
        String line = "";
        try {
            reader = new BufferedReader(new FileReader(fisierActiuni));
            while ((line = reader.readLine()) != null) {
                String[] row = line.split(",");

                for (String i : row) {
                    System.out.printf("%-10s", i);
                }
                System.out.println();
            }
        } catch (Exception e) {

        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

}


