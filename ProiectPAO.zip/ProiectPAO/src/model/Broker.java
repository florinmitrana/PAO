package model;
import Service.BrokerInt;
import model.Actiune;
import model.Transaction;
import model.Portofoliu;
import java.util.Map;
import java.util.TreeMap;


import java.util.List;

public class Broker implements BrokerInt {
    private String nume;
    private double RataComision;

    public Broker(String nume, double rataComision) {
        this.nume = nume;
        RataComision = rataComision;
    }

    @Override
    public String getNume() {
        return nume;
    }

    @Override
    public void setNume(String nume) {
        this.nume = nume;
    }

    @Override
    public double getRataComision() {
        return RataComision;
    }

    @Override
    public void setRataComision(double rataComision) {
        RataComision = rataComision;
    }

    @Override
    public double calculeazaComision(Transaction tranzactie) {
        double pret = tranzactie.getActiune().getPret();
        double cantitate = tranzactie.getTransaction_quantity();
        double valoare = pret * cantitate;
        double comision = RataComision * valoare / 100;
        return comision;

    }

    @Override
    public Map<Double, String> getBrokeriOrdonati(List<Broker> brokeri) {
        Map<Double, String> brokeriOrdonati = new TreeMap<>();

        for (Broker broker : brokeri) {
            brokeriOrdonati.put(broker.getRataComision(), broker.getNume());
        }

        return brokeriOrdonati;
    }
}
