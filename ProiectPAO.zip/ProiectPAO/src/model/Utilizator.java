package model;

import Implementation.ServTranzactionareImpl;
import Service.UtilizatorInt;
import model.Actiune;
import model.Portofoliu;

import java.util.ArrayList;
import java.util.List;
public class Utilizator extends ServTranzactionareImpl implements UtilizatorInt {
    private String nume;
    private String id;
    private String adresaEmail;
    private Portofoliu portofoliu;

    public Utilizator(String nume, String id, String adresaEmail, Portofoliu portofoliu) {
        this.nume = nume;
        this.id = id;
        this.adresaEmail = adresaEmail;
        this.portofoliu = portofoliu;
        System.out.println("Utilizatorul cu numele "+nume+" si id-ul "+id+" a fost creeat cu success.\n");
    }

    @Override
    public double valoarePortofoliu(Portofoliu portofoliu) {
        return super.valoarePortofoliu(portofoliu);
    }
    @Override
    public String getNume() {
        return nume;
    }
    @Override
    public void setNume(String nume) {
        this.nume = nume;
    }
    @Override
    public String getId() {
        return id;
    }
    @Override
    public void setId(String id) {
        this.id = id;
    }
    @Override
    public String getAdresaEmail() {
        return adresaEmail;
    }
    @Override
    public void setAdresaEmail(String adresaEmail) {
        this.adresaEmail = adresaEmail;
    }
    @Override
    public Portofoliu getPortofoliu() {
        return portofoliu;
    }
    @Override
    public void setPortofoliu(Portofoliu portofoliu) {
        this.portofoliu = portofoliu;
    }
    @Override
    public void adaugaActiuneInPortofoliu(Actiune actiune){
        portofoliu.adaugaActiune(actiune);
    }
    @Override
    public void afisareActiuni(){
        List<Actiune> actiuni = portofoliu.getActiuni();
        List<Actiune> numeActiuni = new ArrayList<>();
        ServTranzactionareImpl serviciu = new ServTranzactionareImpl();

        for (Actiune actiune : actiuni){
            if (!(numeActiuni.contains(actiune)) ){
                numeActiuni.add(actiune);
            }
        }
        for (Actiune actiune : numeActiuni){
            if(actiune instanceof  Criptomoneda) {
                System.out.println("Criptomoneda " + actiune + " se afla in cantitatea de " +
                        serviciu.numarActiuni(portofoliu, actiune.getNume()) +
                        " si are pretul de " + actiune.getPret());
            }
            else{
                System.out.println("Actiunea " + actiune + " se afla in cantitatea de " +
                        serviciu.numarActiuni(portofoliu, actiune.getNume()) +
                        " si are pretul de " + actiune.getPret());

            }
        }
    }
}
