package model;
import Service.TransactionInt;
import model.Portofoliu;
import model.Actiune;
import java.util.Calendar;
import java.util.Date;
public class Transaction implements TransactionInt {
    private int Transaction_id;
    private Date Transaction_time;
    private Portofoliu portofoliu;
    private PortofoliuCrypto portofoliuCrypto;
    private Actiune actiune;
    private  int Transaction_quantity;

    public Transaction(int transaction_id, Date transaction_time, Portofoliu portofoliu,PortofoliuCrypto portofoliuCrypto, Actiune actiune, int transaction_quantity) {
        this.Transaction_id = transaction_id;
        this.Transaction_time = transaction_time;
        this.portofoliu = portofoliu;
        this.portofoliuCrypto= portofoliuCrypto;
        this.actiune = actiune;
        this.Transaction_quantity = transaction_quantity;
    }
    @Override
    public int getTransaction_id() {
        return Transaction_id;
    }
    @Override
    public void setTransaction_id(int transaction_id) {
        Transaction_id = transaction_id;
    }
    @Override
    public Date getTransaction_time() {
        return Transaction_time;
    }
    @Override
    public void setTransaction_time(Date transaction_time) {
        Transaction_time = transaction_time;
    }
    @Override
    public Portofoliu getPortofoliu() {
        return portofoliu;
    }
    @Override
    public void setPortofoliu(Portofoliu portofoliu) {
        this.portofoliu = portofoliu;
    }
    @Override
    public Actiune getActiune() {
        return actiune;
    }
    @Override
    public void setActiune(Actiune actiune) {
        this.actiune = actiune;
    }
    @Override
    public int getTransaction_quantity() {
        return Transaction_quantity;
    }
    @Override
    public Portofoliu getPortofoliuCrypto(){ return portofoliuCrypto;}
    @Override
    public void setPortofoliuCrypto(PortofoliuCrypto portofoliuCrypto){this.portofoliuCrypto = portofoliuCrypto;}
    @Override
    public void setTransaction_quantity(int transaction_quantity) {
        Transaction_quantity = transaction_quantity;
    }
    @Override
    public void cumparaActiuni(){
        for(int i=0; i<Transaction_quantity; i++){
            if (actiune instanceof  Criptomoneda)
                portofoliuCrypto.adaugaActiune(actiune);
            else if (actiune instanceof Actiune)
                portofoliu.adaugaActiune(actiune);
        }
        if(actiune instanceof Criptomoneda) {
            System.out.println("Tranzactia cu id-ul " + Transaction_id + " a fost efectuata in data de " + Transaction_time + " cu succes. ");
            System.out.println("Criptomoneda " + actiune.getNume() + " a fost cumparata de " + Transaction_quantity + " ori la pretul de " + actiune.getPret() + "\n");
        }
        else if (!(actiune instanceof Criptomoneda)){
            System.out.println("Tranzactia cu id-ul " + Transaction_id + " a fost efectuata in data de " + Transaction_time + " cu succes. ");
            System.out.println("Actiunea " + actiune.getNume() + " a fost cumparata de " + Transaction_quantity + " ori la pretul de " + actiune.getPret() + "\n");
        }
    }
    @Override
    public void vindeActiuni(){
        for(int i=0; i<Transaction_quantity; i++){
            if (actiune instanceof  Criptomoneda)
                portofoliuCrypto.stergeActiune(actiune);
            else if (actiune instanceof Actiune)
                portofoliu.stergeActiune(actiune);
        }

        if(actiune instanceof Criptomoneda) {

            System.out.println("Tranzactia cu id-ul " + Transaction_id + " a fost efectuata in data de " + Transaction_time + " cu succes. ");
            System.out.println("Criptomoneda " + actiune.getNume() + " a fost cumparata de " + Transaction_quantity + " ori la pretul de " + actiune.getPret() + "\n");
        }
        else if (!(actiune instanceof Criptomoneda)){
            System.out.println("Tranzactia cu id-ul " + Transaction_id + " a fost efectuata in data de " + Transaction_time + " cu succes. ");
            System.out.println("Actiunea " + actiune.getNume() + " a fost cumparata de " + Transaction_quantity + " ori la pretul de " + actiune.getPret() + "\n");
        }
    }

}
