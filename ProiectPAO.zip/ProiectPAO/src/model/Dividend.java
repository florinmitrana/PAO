package model;
import Service.DividendInt;
import model.Actiune;
public class Dividend implements DividendInt {
    public Dividend() {
    }
    @Override
    public void dividendActiune(Actiune actiune,double valdiv){
        double valoare = actiune.getPret()*valdiv/100;
        System.out.println("Actiunea "+ actiune.getNume()+ " ofera dividende in valoare de "+ valoare+"\n");

    }
}
