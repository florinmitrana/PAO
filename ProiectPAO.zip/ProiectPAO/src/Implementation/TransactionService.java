package Implementation;
import DatabaseService.TransactionServiceInt;
import model.Transaction;

import java.sql.*;
import java.util.List;
public class TransactionService implements TransactionServiceInt {
    private Connection connection;

    public TransactionService(Connection connection) {
        this.connection = connection;
    }
    @Override
    public void insertTranzactie(Transaction tranzactie){
        var insertSql = "INSERT INTO tranzactie (id,data,portofoliu,portofoliuCrypto,actiune,cantitate) VALUES (?,?,?,?,?,?)";
        try (var preparedStatement = connection.prepareStatement(insertSql)) {
            preparedStatement.setInt(1, tranzactie.getTransaction_id());
            preparedStatement.setString(2, String.valueOf(tranzactie.getTransaction_time()));
            preparedStatement.setString(3, String.valueOf(tranzactie.getPortofoliu()));
            preparedStatement.setString(4, String.valueOf(tranzactie.getPortofoliuCrypto()));
            preparedStatement.setString(5, tranzactie.getActiune().getNume() );
            preparedStatement.setInt(6, tranzactie.getTransaction_quantity());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 1) {
                System.out.println("Tranzactia cu ID-ul " + tranzactie.getTransaction_id() + " a fost inserata cu succes in tabel.");
            } else
                System.out.println("Eroare la inserarea Tranzactiei cu ID-ul  " + tranzactie.getTransaction_id() + " in tabel");


        } catch (SQLException e) {

        }
    }

    @Override
    public void selectTranzactie(Transaction tranzactie){
        var selectSql = "SELECT * from tranzactie WHERE id = ?";
        try(var preparedStatement = connection.prepareStatement(selectSql)){
            preparedStatement.setInt(1, tranzactie.getTransaction_id());
            try (var resultSet = preparedStatement.executeQuery()){
                while (resultSet.next()){
                    int id = resultSet.getInt("id");
                    String timp = resultSet.getString("data");
                    String porto = resultSet.getString("portofoliu");
                    String portoCrypto = resultSet.getString("portofoliuCrypto");
                    String actiune = resultSet.getString("actiune");
                    int cantitate = resultSet.getInt("cantitate");
                    System.out.println("ID: "+ id + "Data: "+ timp + "Portofoliu: "+porto + "Portofoliu Crypto "+ portoCrypto+ "Actiune: "+ actiune +"Cantitate: "+ cantitate);
                }

            }
        }
        catch( SQLException e){
            System.out.println("Eroare: "+ e.getMessage());
        }
    }
@Override
    public void updateTranzactie(Transaction tranzactie, int cantitate){
        var updateSql = "UPDATE tranzactie SET cantitate = ? WHERE id = ?";
        try(PreparedStatement preparedStatement = connection.prepareStatement(updateSql)){
            preparedStatement.setInt(1, cantitate);
            preparedStatement.setInt(2, tranzactie.getTransaction_id());

            int rowsUpdated= preparedStatement.executeUpdate();

            if(rowsUpdated> 0){
                System.out.println("Tranzactie cu ID-ul "+ tranzactie.getTransaction_id() + "a fost updatata cu succes.");
                tranzactie.setTransaction_quantity(cantitate);
            }
            else
                System.out.println("Eroare la updatarea tranzactiei cu ID-ul "+ tranzactie.getTransaction_id());

        }catch(SQLException e){
            System.out.println("Eroare: "+e.getMessage());
        }
    }

    @Override
    public void deleteTranzactie(Transaction transaction){
        var deleteSql = "DELETE FROM tranzactie WHERE id = ? ";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSql)){
            preparedStatement.setInt(1, transaction.getTransaction_id());

            int rowsUpdated = preparedStatement.executeUpdate();

            if(rowsUpdated>0){
                System.out.println("Tranzactia cu ID-ul "+transaction.getTransaction_id() +" a fost stearsa cu succes.");
            }
            else
                System.out.println("Eroare la stergerea tranzactiei cu ID-ul "+ transaction.getTransaction_id());
        }catch(SQLException e){
            System.out.println("Eroare la stergerea tranzactiei cu ID-ul "+ transaction.getTransaction_id());
        }

    }

}


