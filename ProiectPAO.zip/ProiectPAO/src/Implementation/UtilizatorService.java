package Implementation;

import DatabaseService.UtilizatorServiceInt;
import model.Utilizator;

import java.sql.*;

public class UtilizatorService implements UtilizatorServiceInt {
    private Connection connection;

    public UtilizatorService(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void insertUtilizator(Utilizator utilizator){
        var insertSql =" INSERT INTO utilizator(nume,id,adresaEmail,portofoliu) VALUES (?,?,?,?)";

        try (var preparedStatement = connection.prepareStatement(insertSql)){
            preparedStatement.setString(1, utilizator.getNume());
            preparedStatement.setString(2, utilizator.getId());
            preparedStatement.setString(3, utilizator.getAdresaEmail());
            preparedStatement.setString(4, String.valueOf(utilizator.getPortofoliu()));

            int rowsAffected = preparedStatement.executeUpdate();
            if( rowsAffected == 1){
                System.out.println("Utilizatorul cu ID-ul "+ utilizator.getId() + " a fost inserat cu succes in tabel.");
            } else
                System.out.println("Eroare la inserarea utilizatorului cu ID-ul "+ utilizator.getId());

        }catch (SQLException e){

        }
    }
@Override
    public void selectUtilizator(Utilizator utilizator){
        var selectSql = "SELECT * from utilizator WHERE id  = ?";
        try(var preparedStatement  = connection.prepareStatement(selectSql)){
            preparedStatement.setString(1,utilizator.getId());
            try( var resultSet = preparedStatement.executeQuery()){
                while(resultSet.next()){
                    String nume  = resultSet.getString("nume");
                    String id = resultSet.getString("id");
                    String adresaEmail = resultSet.getString("adresaEmail");
                    String portofoliu = resultSet.getString("portofoliu");
                    System.out.println(" ID: "+id+" Nume: "+nume+" Adresa Email: "+adresaEmail+" Portofoliu :"+portofoliu);

                }
            }


        }catch (SQLException e){
            System.out.println("Eroare: "+ e.getMessage());
        }
    }
@Override
    public void updateUtilizator(Utilizator utilizator,String nume, String adresaEmail){
        var updateSql = "UPDATE utilizator SET nume = ? ,adresaEmail = ? WHERE id = ?";
        try(PreparedStatement preparedStatement = connection.prepareStatement(updateSql)){
            preparedStatement.setString(1,nume);
            preparedStatement.setString(2,adresaEmail);
            preparedStatement.setString(3, utilizator.getId());

            int rowsUpdated = preparedStatement.executeUpdate();

            if(rowsUpdated > 0){
                System.out.println("Utilizatorul cu ID-ul : "+ utilizator.getId()+ "a fost updatat cu succes.");
                utilizator.setAdresaEmail(adresaEmail);
                utilizator.setNume(nume);
            }
            else
                System.out.println("Eroare la updatarea utilizatorului :"+ utilizator.getId());
        }catch (SQLException e) {
            System.out.println("Eroare : " + e.getMessage());
        }
    }
@Override
    public void deleteUtilizator(Utilizator utilizator){
        var deleteSql = "DELETE FROM utilizator WHERE id = ?";
        try(PreparedStatement preparedStatement = connection.prepareStatement(deleteSql)){
            preparedStatement.setString(1,utilizator.getId());

            int rowsUpdated = preparedStatement.executeUpdate();

            if(rowsUpdated > 0 ){
                System.out.println("Utilizatorul cu ID-ul "+utilizator.getId() + "a fost sters cu succes.");
            }
            else
                System.out.println("Eroare la stergerea utilizatorului cu ID-ul :"+utilizator.getId() );
        }catch (SQLException e){
            System.out.println("Eroare la stergerea utilizatorului: "+e.getMessage());
        }
    }
}
