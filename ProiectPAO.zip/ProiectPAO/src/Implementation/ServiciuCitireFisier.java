package Implementation;

import Service.ServiciuCitireFisierInt;

import java.io.*;
public class ServiciuCitireFisier implements ServiciuCitireFisierInt {
    private static ServiciuCitireFisier instance =  null;

    private ServiciuCitireFisier(){

    }
    public static synchronized ServiciuCitireFisier getInstance(){
        if(instance == null){
            instance = new ServiciuCitireFisier();
        }
        return instance;
    }

    public void CitireAfisareFisier(String NumeFisier){
        BufferedReader reader = null;
        String line = "";
        try {
            reader = new BufferedReader(new FileReader(NumeFisier));
            while ((line = reader.readLine()) != null) {

                String[] row = line.split(",");

                for (String i : row) {
                    System.out.printf("%-10s", i);
                }

                System.out.println();
            }
        }

        catch (IOException e) {
            System.out.println("Ramura Exceptie");
        }

        finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.out.println("Ramura Exceptie");
                }
            }
        }
    }
}
