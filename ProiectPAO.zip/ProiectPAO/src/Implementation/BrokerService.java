package Implementation;

import DatabaseService.BrokerServiceInt;
import model.Broker;

import java.sql.*;
public class BrokerService implements BrokerServiceInt {
    private Connection connection;

    public BrokerService(Connection connection) {
        this.connection = connection;
    }
@Override
    public void insertBroker(Broker broker) {
        var insertSql = "INSERT INTO broker (nume, rataComision) VALUES (?,?)";
        try (var preparedStatement = connection.prepareStatement(insertSql)) {
            preparedStatement.setString(1, broker.getNume());
            preparedStatement.setDouble(2, broker.getRataComision());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 1) {
                System.out.println("Brokerul cu numele " + broker.getNume() + " a fost inserat cu succes in tabel.");
            } else
                System.out.println("Eroare la inserarea brokerului cu numele : " + broker.getNume());
        } catch (SQLException e) {

        }
    }
@Override
    public void selectBroker(Broker broker) {
        var selectSql = "SELECT * from broker WHERE nume = ?";
        try (var preparedStatement = connection.prepareStatement(selectSql)) {
            preparedStatement.setString(1,broker.getNume());

            try(var resultSet = preparedStatement.executeQuery()){
                while (resultSet.next()){
                    String nume  = resultSet.getString("nume");
                    double rataComision = resultSet.getDouble("rataComision");
                    System.out.println("Nume: "+ nume + " Rata Comision: "+ rataComision);
                }
            }

        } catch (SQLException e) {
            System.out.println("Eroare: "+ e.getMessage());
        }

    }
@Override
    public void updateBroker(Broker broker, double rataComision){
        var updateSql = "UPDATE broker SET rataComision = ? WHERE nume =?";
        try(PreparedStatement preparedStatement = connection.prepareStatement(updateSql)){
            preparedStatement.setDouble(1,rataComision);
            preparedStatement.setString(2, broker.getNume());

            int rowsUpdated = preparedStatement.executeUpdate();

            if(rowsUpdated > 0){
                System.out.println("Broker-ul cu numele :"+ broker.getNume()+" a fost updatat cu succes.");
                broker.setRataComision(rataComision);
            }
            else
                System.out.println("Eroarea la updatarea brokerului cu numele: "+ broker.getNume());
        }catch(SQLException e){

        }

    }
@Override
    public void deleteBroker(Broker broker){
        var deleteSql = "DELETE FROM broker WHERE nume = ?";
        try(PreparedStatement preparedStatement = connection.prepareStatement(deleteSql)){
            preparedStatement.setString(1,broker.getNume());

            int rowsUpdated = preparedStatement.executeUpdate();

            if(rowsUpdated > 0)
                System.out.println("Brokerul cu numele : "+ broker.getNume()+" a fost sters cu succes.");
            else
                System.out.println("Eroare la stergerea brokerului cu numele : "+ broker.getNume());
        }catch (SQLException e){
            System.out.println("Eroare la stergerea brokerului cu numele : "+ broker.getNume());
        }
    }
}

