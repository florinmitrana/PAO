package Implementation;
import model.Actiune;
import model.Portofoliu;
import Service.ServTranzactionare;

import java.util.List;

public class ServTranzactionareImpl implements ServTranzactionare {

    @Override
    public int numarActiuni(Portofoliu portofoliu, String numeActiune) {
        List<Actiune> actiuni = portofoliu.getActiuni();
        int nr =0 ;
        for (Actiune actiune : actiuni){
            if (actiune.getNume().equals(numeActiune))
                nr++;
        }
        return nr;
    }

    @Override
    public double valoarePortofoliu(Portofoliu portofoliu) {
        List<Actiune> actiuni = portofoliu.getActiuni();
        double valoare = 0.0;
        for(Actiune actiune : actiuni){
            valoare = valoare + actiune.getPret();
        }
        return valoare;
    }
}
