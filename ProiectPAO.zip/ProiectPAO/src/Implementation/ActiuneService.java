package Implementation;

import DatabaseService.ActiuneServiceInt;
import model.Actiune;

import java.sql.*;
import java.util.List;


public class ActiuneService implements ActiuneServiceInt {
    private Connection connection;
    public ActiuneService(Connection connection) {
        this.connection = connection;
    }
@Override
    public void insertActiuni(List<Actiune> actiuni){
        int index =0;
        for(Actiune actiune : actiuni) {
            index = index+1;
            var insertSql = "INSERT INTO actiune (id,nume,simbol,pret,marketCap) VALUES (?,?,?,?,?)";
            try (var preparedStatement = connection.prepareStatement(insertSql)) {
                preparedStatement.setInt(1, index);
                preparedStatement.setString(2, actiune.getNume());
                preparedStatement.setString(3, actiune.getSimbol());
                preparedStatement.setDouble(4, actiune.getPret());
                preparedStatement.setLong(5, actiune.getMarketCap());
                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected == 1) {
                    System.out.println("Actiunea " + actiune.getNume() + " a fost inserata cu succes in tabel.");
                } else
                    System.out.println("Eroare la inserarea actiunii " + actiune.getNume() + " in tabel");


            } catch (SQLException e) {

            }
        }

    }

    @Override
    public void selectActiune(Actiune actiune) {

        var selectSql = "SELECT * FROM actiune WHERE nume = ?";
        try (var preparedStatement = connection.prepareStatement(selectSql)) {
            preparedStatement.setString(1, actiune.getNume());

            try(var resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String nume = resultSet.getString("nume");
                    String simbol = resultSet.getString("simbol");
                    Double pret = resultSet.getDouble("pret");
                    long marketCap = resultSet.getLong("marketCap");
                    System.out.println("ID: " + id + ", Nume: " + nume + ", Simbol: " + simbol + ", Pret: " + pret + ", Market Cap: " + marketCap);
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void updateActiune(Actiune actiune, int id, double pret, int marketCap){
        var updateSql = "UPDATE actiune SET pret = ?, marketCap= ? WHERE id = ? ";
        try( PreparedStatement preparedStatement = connection.prepareStatement(updateSql)){
            preparedStatement.setDouble(1,pret);
            preparedStatement.setInt(2,marketCap);
            preparedStatement.setInt(3,id);

            int rowsUpdated = preparedStatement.executeUpdate();

            if(rowsUpdated > 0){
                System.out.println("Actiunea cu ID-ul "+ id + " a fost actualizata cu succes.");
                actiune.setPret(pret);
                actiune.setMarketCap(marketCap);
            } else {
                System.out.println("Nu s-au gasit inregistrari pentru actiunea cu id-ul "+ id);
            }



        } catch (SQLException e){
            System.out.println("Eroare la actualizarea actiunii cu id-ul "+ id + " : "+ e.getMessage());
        }

    }

    @Override
    public void deleteActiune(Actiune actiune){
        var deleteSql = "DELETE FROM actiune WHERE nume = ? ";
        try( PreparedStatement preparedStatement = connection.prepareStatement(deleteSql)){
            preparedStatement.setString(1,actiune.getNume());

            int rowsUpdated = preparedStatement.executeUpdate();

            if(rowsUpdated > 0){
                System.out.println("Actiunea cu numele " + actiune.getNume()+ " a fost stearsa cu succes din baza de date.");
            } else{
                System.out.println("Nu s-au gasit inregistrari pentru actiunea cu numele "+ actiune.getNume());
            }

        }catch(SQLException e){
            System.out.println("Eroare la stergerea actiunii cu numele "+ actiune.getNume()+ ": "+ e.getMessage());

        }
    }

}