package DatabaseService;

import model.Broker;

public interface BrokerServiceInt {
    public void insertBroker(Broker broker);
    public void selectBroker(Broker broker);
    public void updateBroker(Broker broker, double rataComision);
    public void deleteBroker(Broker broker);
}
