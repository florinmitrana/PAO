package DatabaseService;

import model.Actiune;

import java.util.List;

public interface ActiuneServiceInt {
    public void insertActiuni(List<Actiune> actiuni);

    public void selectActiune(Actiune actiune);

    public void updateActiune(Actiune actiune, int id, double pret, int marketCap);

    public void deleteActiune(Actiune actiune);
}
