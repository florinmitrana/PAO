package DatabaseService;

import model.Utilizator;

public interface UtilizatorServiceInt {

    public void insertUtilizator(Utilizator utilizator);

    public void selectUtilizator(Utilizator utilizator);

    public void updateUtilizator(Utilizator utilizator,String nume, String adresaEmail);

    public void deleteUtilizator(Utilizator utilizator);
}
