package DatabaseService;

import model.Transaction;

public interface TransactionServiceInt {

    public void insertTranzactie(Transaction tranzactie);

    public void selectTranzactie(Transaction tranzactie);

    public void updateTranzactie(Transaction tranzactie, int cantitate);

    public void deleteTranzactie(Transaction transaction);
}
